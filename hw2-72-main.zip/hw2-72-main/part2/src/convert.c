#include <stdio.h>
#include <stdlib.h>

int main() {
    return EXIT_SUCCESS;
}
